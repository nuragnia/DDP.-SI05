import math

def l_kubus(sisi):
    volume = sisi ** 3
    luas = 6 * (sisi ** 2)
    print('luas permukaan balok adalah, ', 6, 'x', {sisi, '^', 2}, '=', luas)
    print('luas volume balok adalah', sisi, '^', 3, '=', volume)

def l_balok(panjang, lebar, tinggi):
    volume = panjang * lebar * tinggi
    luas = 2 * panjang * lebar + panjang * tinggi + lebar * tinggi
    print('luas permukaan balok adalah', 2, 'x', panjang, 'x', lebar, '+', panjang, 'x', tinggi, '+', lebar, 'x', tinggi, '=', luas)
    print('volume balok adalah, ', panjang, 'x', lebar, 'x', tinggi, '=', volume)

def l_bola(jari_jari):
    volume = 4/3 * math.pi * jari_jari ** 3
    luas = 4 * math.pi * jari_jari ** 2
    print('luas permukaan bola adalah, ', 4/3, 'x', math.pi, 'x', jari_jari, '^', 3, '=', luas)
    print('volume bola adalah, ', 4/3, 'x', math.pi, 'x', jari_jari, '^', 3, '=', volume)


def l_tabung(jari_jari, tinggi):
    volume = math.pi * jari_jari ** 2 * tinggi
    luas = 2 * math.pi * jari_jari * jari_jari + tinggi
    print('luas permukaan tabung adalah, ', 2, 'x', math.pi, 'x', jari_jari, 'x', jari_jari, '+', tinggi, '=', luas)
    print('volume tabung adalah, ', math.pi, 'x', jari_jari, '^', 2, 'x', tinggi, '=', volume)

def l_kerucut(jari_jari, tinggi, sisi_miring):
    volume = 1/3 * math.pi * jari_jari ** 2* tinggi
    luas = math.pi * jari_jari * jari_jari + sisi_miring
    print('luas permukaan kerucut adalah, ', math.pi, 'x', jari_jari, 'x', jari_jari, '+', sisi_miring, '=', luas)
    print('volume kerucut adalah, ', 1/3, 'x', math.pi, 'x', jari_jari, '^', 2, 'x', tinggi, '=', volume)

