import main

print("-----Perhitungan persegi-----")
main.l_persegi(10)

print()
print("-----Perhitungan persegi panjang-----")
main.l_persegi_panjang(10,4)

print()
print("-----perhitungan segitiga-----")
main.l_segitiga(3,4)

print()
print("------perhitungan lingkaran-----")
main.l_lingkaran(10)

print()
print("------Perhitungan jajar genjang------")
main.l_jajar_genjang(2,3)


