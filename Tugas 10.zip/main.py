import math

def l_persegi(sisi):
    luas = sisi * sisi
    keliling = sisi*sisi*sisi*sisi
    print(f'Luas Persegi {sisi} * {sisi} = {luas} ')
    print(f'keliling persegi adalah{keliling}')

def l_persegi_panjang(panjang, lebar):
    luas = panjang * lebar
    print(f'luas persegi panjang', panjang, 'x', lebar, '=', luas)

def l_segitiga(alas, tinggi):
    luas = 1/2 * alas * tinggi
    print(f'Luas segitiga', 1/2, 'x', alas, 'x', tinggi, '=', luas)

def l_lingkaran(jari_jari):
    luas = math.pi * jari_jari
    print(f'Luas lingkaran', math.pi, 'x', jari_jari, '=', luas)

def l_jajar_genjang(alas, tinggi):
    luas = alas * tinggi
    print(f'luas jajar genjang', alas, 'x', tinggi, '=', luas)


