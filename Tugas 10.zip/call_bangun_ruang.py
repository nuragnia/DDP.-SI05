import bangun

print("-----kubus-----")
bangun.l_kubus(7)

print("-----balok-----")
bangun.l_balok(3,4,7)

print("-----bola-----")
bangun.l_bola(2)

print("-----tabung-----")
bangun.l_tabung(3,7)

print("-----kerucut-----")
bangun.l_kerucut(5,8,9)




