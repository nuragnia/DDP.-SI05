print('-------gunakan modul--------')
import hitung as hitung
hitung.tambah(5,2)
hitung.kurang(10,3)
hitung.kali(5,6)

print()
print('/n--gunakan modul yg ada dengan alias--')
import hitung as hitung 
hitung.bagi(20,2)
hitung.pangkat(2,3)

print()
print('/n--gunakan modul dengan memanggil sebagai fungsinya--')
from hitung import tambah,kurang
tambah(20,30)
kurang(2,3)

print()
print('\n--gunakan modul dengan memanggil sebagai fungsinya dengan alias---')
from hitung import tambah as add, kali as x, kurang as m
add(3,7)
x(10,10)
m(10,5)